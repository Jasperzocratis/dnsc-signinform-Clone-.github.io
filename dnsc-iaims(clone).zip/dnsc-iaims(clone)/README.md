# iaims clone page form Design #1
You can open the code in ([Open in Youtube](https://github.com/Jasperzocratis)).

# Screenshot
Here we have layout screenshot :

![screenshot](/clone-page-design.png)
